"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const logger_1 = require("./libs/logger");
const handler = async (event) => {
    logger_1.logger.info('Event', { event });
    return {
        statusCode: 200,
        body: `Action ${event.action} instance completed successfully.`
    };
};
exports.handler = handler;
