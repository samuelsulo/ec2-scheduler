"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Action = void 0;
var Action;
(function (Action) {
    Action["OPEN"] = "open";
    Action["CLOSE"] = "close";
})(Action = exports.Action || (exports.Action = {}));
